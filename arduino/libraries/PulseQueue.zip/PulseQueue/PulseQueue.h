#ifndef PULSEQUEUE_H
#define PULSEQUEUE_H

#include <Arduino.h>

struct PulseCmd {
    char dir;     // 'f' or 'b'
    int speed;    // 0–255 (abs)
    int pulses;   // number of pulses required
    int angle;    // servo target angle
};

class PulseQueue {
public:
    static const int DEFAULT_CAPACITY = 16;

    PulseQueue(int capacity = DEFAULT_CAPACITY);
    ~PulseQueue();

    bool enqueue(const PulseCmd &cmd);
    bool dequeue(PulseCmd &outCmd);

    void clear();
    bool isEmpty() const;
    bool isFull() const;

    int count() const;
    int capacity() const;

    bool parseAndEnqueue(const String &line);

private:
    PulseCmd *buffer;
    int bufCapacity;
    int head;
    int tail;
    int size;

    String getNextToken(const String &line, int &pos);
};

#endif
