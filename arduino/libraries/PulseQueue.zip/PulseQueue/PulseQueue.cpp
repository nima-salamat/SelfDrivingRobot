#include "PulseQueue.h"

PulseQueue::PulseQueue(int capacity) {
    if (capacity <= 0) capacity = DEFAULT_CAPACITY;

    bufCapacity = capacity;
    buffer = new PulseCmd[bufCapacity];
    head = 0;
    tail = 0;
    size = 0;
}

PulseQueue::~PulseQueue() {
    delete[] buffer;
}

bool PulseQueue::enqueue(const PulseCmd &cmd) {
    if (size >= bufCapacity)
        return false;

    buffer[tail] = cmd;
    tail = (tail + 1) % bufCapacity;
    size++;
    return true;
}

bool PulseQueue::dequeue(PulseCmd &outCmd) {
    if (size == 0)
        return false;

    outCmd = buffer[head];
    head = (head + 1) % bufCapacity;
    size--;
    return true;
}

void PulseQueue::clear() {
    head = 0;
    tail = 0;
    size = 0;
}

bool PulseQueue::isEmpty() const {
    return size == 0;
}

bool PulseQueue::isFull() const {
    return size >= bufCapacity;
}

int PulseQueue::count() const {
    return size;
}

int PulseQueue::capacity() const {
    return bufCapacity;
}

// ---------------------- Parsing & Enqueueing ----------------------
bool PulseQueue::parseAndEnqueue(const String &line) {
    int pos = 0;
    int len = line.length();
    while (pos < len) {
        String t0 = getNextToken(line, pos);
        if (t0.length() == 0) break;
        char head = tolower(t0.charAt(0));
        if (head != 'f' && head != 'b') continue;

        String sSpeed  = getNextToken(line, pos);
        String sPulses = getNextToken(line, pos);
        String sAngle  = getNextToken(line, pos);
        if (sSpeed.length() == 0 || sPulses.length() == 0 || sAngle.length() == 0) break;

        PulseCmd c;
        c.dir    = head;
        c.speed  = abs(sSpeed.toInt());
        c.pulses = sPulses.toInt();
        c.angle  = sAngle.toInt();

        if (c.pulses <= 0 || c.speed == 0) continue;

        if (!enqueue(c)) return false;
    }
    return true;
}

String PulseQueue::getNextToken(const String &line, int &pos) {
    int len = line.length();
    while (pos < len && (line[pos] == ' ' || line[pos] == '\t' || line[pos] == ',' || line[pos] == ';')) pos++;
    if (pos >= len) return "";
    int start = pos;
    while (pos < len && line[pos] != ' ' && line[pos] != '\t' && line[pos] != ',' && line[pos] != ';') pos++;
    return line.substring(start, pos);
}
