#include "PulseQueue.h"

PulseQueue::PulseQueue(int capacity) {
    if (capacity <= 0) capacity = DEFAULT_CAPACITY;

    bufCapacity = capacity;
    buffer = new PulseCmd[bufCapacity];
    head = 0;
    tail = 0;
    size = 0;
}

PulseQueue::~PulseQueue() {
    delete[] buffer;
}

bool PulseQueue::enqueue(const PulseCmd &cmd) {
    if (size >= bufCapacity)
        return false;

    buffer[tail] = cmd;
    tail = (tail + 1) % bufCapacity;
    size++;
    return true;
}

bool PulseQueue::dequeue(PulseCmd &outCmd) {
    if (size == 0)
        return false;

    outCmd = buffer[head];
    head = (head + 1) % bufCapacity;
    size--;
    return true;
}

void PulseQueue::clear() {
    head = 0;
    tail = 0;
    size = 0;
}

bool PulseQueue::isEmpty() const {
    return size == 0;
}

bool PulseQueue::isFull() const {
    return size >= bufCapacity;
}

int PulseQueue::count() const {
    return size;
}

int PulseQueue::capacity() const {
    return bufCapacity;
}
