#ifndef ENCODER_H
#define ENCODER_H

#include <Arduino.h>

/*
  Encoder - simple pulse counter for single-channel encoders (Hall/reed or optical).
  - Supports optional debounce (use non-zero debounce_us for Hall/reed).
  - edgeMode: RISING, FALLING, or CHANGE (choose appropriate for your sensor).
  - Usage:
      Encoder enc(pin, debounce_us, edgeMode);
      enc.begin();
      enc.reset();
      int count = enc.getCount();
*/

class Encoder {
public:
  Encoder(uint8_t pin, unsigned long debounce_us = 0UL, int edgeMode = RISING);

  // Call in setup() to attach ISR and configure pin
  void begin();

  // Atomically reset counter to zero
  void reset();

  // Atomically read counter
  int getCount();

  // Optional: change debounce at runtime
  void setDebounce(unsigned long debounce_us);

private:
  uint8_t _pin;
  unsigned long _debounceUs;
  int _edgeMode;

  // ISR uses these static members
  static volatile int _counter;
  static volatile unsigned long _lastMicros;
  static Encoder* _instance;

  // Static ISR that forwards to instance for debounce-less / debounce behaviour
  static void isr();

  // Non-static handler called by isr()
  void handleInterrupt();
};

#endif // ENCODER_H
