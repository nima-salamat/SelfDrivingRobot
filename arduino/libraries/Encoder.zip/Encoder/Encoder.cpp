#include "Encoder.h"

volatile int Encoder::_counter = 0;
volatile unsigned long Encoder::_lastMicros = 0;
Encoder* Encoder::_instance = nullptr;

Encoder::Encoder(uint8_t pin, unsigned long debounce_us, int edgeMode)
  : _pin(pin), _debounceUs(debounce_us), _edgeMode(edgeMode) {}

void Encoder::begin() {
  // Sensor pin configuration:
  // HALL: use INPUT_PULLUP if using typical reed/hall with contact to GND
  // LASER: if using open-collector optical module prefer external pull-up or INPUT (and external pull-up)
  // We'll set INPUT_PULLUP by default because it's safe for Hall. Change to pinMode(_pin, INPUT) if using external pull-up.
  pinMode(_pin, INPUT_PULLUP);

  _instance = this;
  // Attach ISR; static Encoder::isr will call instance->handleInterrupt()
  attachInterrupt(digitalPinToInterrupt(_pin), Encoder::isr, _edgeMode);
}

void Encoder::reset() {
  noInterrupts();
  _counter = 0;
  interrupts();
}

int Encoder::getCount() {
  noInterrupts();
  int c = _counter;
  interrupts();
  return c;
}

void Encoder::setDebounce(unsigned long debounce_us) {
  _debounceUs = debounce_us;
}

void Encoder::isr() {
  if (_instance) _instance->handleInterrupt();
}

void Encoder::handleInterrupt() {
  if (_debounceUs > 0) {
    // Debounce logic for mechanical sensors (Hall / reed)
    unsigned long now = micros();
    if (now - _lastMicros >= _debounceUs) {
      _counter++;
      _lastMicros = now;
    }
  } else {
    // No debounce => intended for optical / laser encoder (fast, clean pulses)
    _counter++;
  }
}
