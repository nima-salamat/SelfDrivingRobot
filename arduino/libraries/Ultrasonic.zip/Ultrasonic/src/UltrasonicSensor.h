#pragma once
#include <Arduino.h>

class UltrasonicSensor {
    public:

        UltrasonicSensor(int trigPin, int echoPin, unsigned long timeoutUs = 30000UL);

        void begin();

        int readCm();

        unsigned long readDuration();

    private:
        int _trig;
        int _echo;
        unsigned long _timeout;
};