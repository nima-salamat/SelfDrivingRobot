#include "UltrasonicSensor.h"

UltrasonicSensor::UltrasonicSensor(int trigPin, int echoPin, unsigned long timeoutUs): _trig(trigPin), _echo(echoPin), _timeout(timeoutUs)
{}

void UltrasonicSensor::begin(){
    pinMode(_trig, OUTPUT);
    pinMode(_echo, INPUT);
    digitalWrite(_trig, LOW);
}

unsigned long UltrasonicSensor::readDuration(){
    digitalWrite(_trig, LOW);
    delayMicroseconds(2);
    digitalWrite(_trig, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trig, LOW);

    return pulseIn(_echo, HIGH, _timeout);
}

int UltrasonicSensor::readCm(){
        unsigned long duration = readDuration();
    if (duration == 0)
        return 9999;

    return (int)(duration / 58.2);
}